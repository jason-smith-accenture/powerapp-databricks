/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../shared/theme/AppThemeProvider.tsx"
/*!***********************************************!*\
  !*** ../../shared/theme/AppThemeProvider.tsx ***!
  \***********************************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.AppThemeProvider = void 0;\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar react_components_1 = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\nvar AppThemeProvider = function AppThemeProvider(_a) {\n  var children = _a.children;\n  return React.createElement(react_components_1.FluentProvider, {\n    theme: react_components_1.webLightTheme\n  }, children);\n};\nexports.AppThemeProvider = AppThemeProvider;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../../shared/theme/AppThemeProvider.tsx?\n}");

/***/ },

/***/ "../../shared/theme/index.ts"
/*!***********************************!*\
  !*** ../../shared/theme/index.ts ***!
  \***********************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.appTokens = exports.AppThemeProvider = void 0;\nvar AppThemeProvider_1 = __webpack_require__(/*! ./AppThemeProvider */ \"../../shared/theme/AppThemeProvider.tsx\");\nObject.defineProperty(exports, \"AppThemeProvider\", ({\n  enumerable: true,\n  get: function get() {\n    return AppThemeProvider_1.AppThemeProvider;\n  }\n}));\nvar tokens_1 = __webpack_require__(/*! ./tokens */ \"../../shared/theme/tokens.ts\");\nObject.defineProperty(exports, \"appTokens\", ({\n  enumerable: true,\n  get: function get() {\n    return tokens_1.appTokens;\n  }\n}));\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../../shared/theme/index.ts?\n}");

/***/ },

/***/ "../../shared/theme/tokens.ts"
/*!************************************!*\
  !*** ../../shared/theme/tokens.ts ***!
  \************************************/
(__unused_webpack_module, exports) {

eval("{\n\n// custom design layer\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.appTokens = void 0;\nexports.appTokens = {\n  spacing: {\n    xs: \"4px\",\n    sm: \"8px\",\n    md: \"12px\",\n    lg: \"16px\",\n    xl: \"24px\",\n    xxl: \"32px\"\n  },\n  radius: {\n    sm: \"4px\",\n    md: \"8px\",\n    lg: \"12px\"\n  },\n  typography: {\n    pageTitle: \"24px\",\n    sectionTitle: \"18px\",\n    body: \"14px\",\n    caption: \"12px\"\n  }\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../../shared/theme/tokens.ts?\n}");

/***/ },

/***/ "./src/SalesTable.tsx"
/*!****************************!*\
  !*** ./src/SalesTable.tsx ***!
  \****************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.SalesTableView = void 0;\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar react_components_1 = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\nvar SalesTableView = function SalesTableView(_a) {\n  var data = _a.data;\n  if (!data) {\n    return React.createElement(\"div\", null, \"No data available.\");\n  }\n  var records;\n  try {\n    records = JSON.parse(data);\n  } catch (_b) {\n    return React.createElement(\"div\", null, \"Invalid sales data.\");\n  }\n  if (!Array.isArray(records) || records.length === 0) {\n    return React.createElement(\"div\", null, \"No data available.\");\n  }\n  return React.createElement(react_components_1.Table, null, React.createElement(react_components_1.TableHeader, null, React.createElement(react_components_1.TableRow, null, React.createElement(react_components_1.TableHeaderCell, null, \"ID\"), React.createElement(react_components_1.TableHeaderCell, null, \"Bank\"), React.createElement(react_components_1.TableHeaderCell, null, \"Asset\"), React.createElement(react_components_1.TableHeaderCell, null, \"Value\"), React.createElement(react_components_1.TableHeaderCell, null, \"Submission date from\"), React.createElement(react_components_1.TableHeaderCell, null, \"Submission date to\"))), React.createElement(react_components_1.TableBody, null, records.map(function (record) {\n    return React.createElement(react_components_1.TableRow, {\n      key: record.id\n    }, React.createElement(react_components_1.TableCell, null, record.id), React.createElement(react_components_1.TableCell, null, record.bank), React.createElement(react_components_1.TableCell, null, record.asset), React.createElement(react_components_1.TableCell, null, record.value.toFixed(2)), React.createElement(react_components_1.TableCell, null, record.submission_date_from || \"N/A\"), React.createElement(react_components_1.TableCell, null, record.submission_date_to || \"N/A\"));\n  })));\n};\nexports.SalesTableView = SalesTableView;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/SalesTable.tsx?\n}");

/***/ },

/***/ "./src/index.ts"
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.SalesTable = void 0;\nvar SalesTable_1 = __webpack_require__(/*! ./SalesTable */ \"./src/SalesTable.tsx\");\nvar theme_1 = __webpack_require__(/*! ../../../shared/theme */ \"../../shared/theme/index.ts\");\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar SalesTable = /** @class */function () {\n  function SalesTable() {\n    this.notifyOutputChanged = function () {};\n  }\n  SalesTable.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  SalesTable.prototype.updateView = function (context) {\n    var _a;\n    var props = {\n      data: (_a = context.parameters.salesData.raw) !== null && _a !== void 0 ? _a : \"\"\n    };\n    return React.createElement(theme_1.AppThemeProvider, null, React.createElement(SalesTable_1.SalesTableView, props));\n  };\n  SalesTable.prototype.getOutputs = function () {\n    return {};\n  };\n  SalesTable.prototype.destroy = function () {\n    // Cleanup if required\n  };\n  return SalesTable;\n}();\nexports.SalesTable = SalesTable;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/index.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	let __webpack_exports__ = __webpack_require__("./src/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Demo.SalesTable', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesTable);
} else {
	var Demo = Demo || {};
	Demo.SalesTable = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesTable;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}