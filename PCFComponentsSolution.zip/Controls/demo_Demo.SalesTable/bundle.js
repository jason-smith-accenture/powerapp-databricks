/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/SalesTable.tsx"
/*!****************************!*\
  !*** ./src/SalesTable.tsx ***!
  \****************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.SalesTableView = void 0;\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nfunction isSalesRecord(value) {\n  if (typeof value !== \"object\" || value === null) {\n    return false;\n  }\n  var record = value;\n  return typeof record.id === \"number\" && typeof record.product === \"string\" && typeof record.region === \"string\" && typeof record.sales === \"number\" && (record.sale_date === undefined || typeof record.sale_date === \"string\");\n}\nfunction parseSalesData(data) {\n  if (!data) {\n    return [];\n  }\n  var parsed = JSON.parse(data);\n  if (!Array.isArray(parsed)) {\n    return [];\n  }\n  return parsed.filter(isSalesRecord);\n}\nvar SalesTableView = function SalesTableView(_a) {\n  var data = _a.data;\n  var records = [];\n  try {\n    records = parseSalesData(data);\n  } catch (_b) {\n    return React.createElement(\"div\", {\n      style: {\n        padding: \"16px\"\n      }\n    }, \"Invalid sales data.\");\n  }\n  if (!records.length) {\n    return React.createElement(\"div\", {\n      style: {\n        padding: \"16px\"\n      }\n    }, \"No sales data available.\");\n  }\n  return React.createElement(\"div\", {\n    style: {\n      width: \"100%\",\n      overflowX: \"auto\"\n    }\n  }, React.createElement(\"h2\", null, \"Sales Dashboard\"), React.createElement(\"table\", {\n    style: {\n      width: \"100%\",\n      borderCollapse: \"collapse\"\n    }\n  }, React.createElement(\"thead\", null, React.createElement(\"tr\", null, React.createElement(\"th\", null, \"ID\"), React.createElement(\"th\", null, \"Product\"), React.createElement(\"th\", null, \"Region\"), React.createElement(\"th\", null, \"Sales\"), React.createElement(\"th\", null, \"Date\"))), React.createElement(\"tbody\", null, records.map(function (record) {\n    return React.createElement(\"tr\", {\n      key: record.id\n    }, React.createElement(\"td\", null, record.id), React.createElement(\"td\", null, record.product), React.createElement(\"td\", null, record.region), React.createElement(\"td\", null, \"$\", record.sales.toFixed(2)), React.createElement(\"td\", null, record.sale_date || \"N/A\"));\n  }))));\n};\nexports.SalesTableView = SalesTableView;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/SalesTable.tsx?\n}");

/***/ },

/***/ "./src/index.ts"
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.SalesTable = void 0;\nvar SalesTable_1 = __webpack_require__(/*! ./SalesTable */ \"./src/SalesTable.tsx\");\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar SalesTable = /** @class */function () {\n  function SalesTable() {\n    // Empty\n  }\n  SalesTable.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  SalesTable.prototype.updateView = function (context) {\n    var _a;\n    var props = {\n      data: (_a = context.parameters.salesData.raw) !== null && _a !== void 0 ? _a : \"\"\n    };\n    return React.createElement(SalesTable_1.SalesTableView, props);\n  };\n  SalesTable.prototype.getOutputs = function () {\n    return {};\n  };\n  SalesTable.prototype.destroy = function () {\n    // Cleanup if required\n  };\n  return SalesTable;\n}();\nexports.SalesTable = SalesTable;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	let __webpack_exports__ = __webpack_require__("./src/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Demo.SalesTable', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesTable);
} else {
	var Demo = Demo || {};
	Demo.SalesTable = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesTable;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}