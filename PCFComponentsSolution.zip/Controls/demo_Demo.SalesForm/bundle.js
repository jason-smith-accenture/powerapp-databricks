/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../shared/theme/AppThemeProvider.tsx"
/*!***********************************************!*\
  !*** ../../shared/theme/AppThemeProvider.tsx ***!
  \***********************************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.AppThemeProvider = void 0;\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar react_components_1 = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\nvar AppThemeProvider = function AppThemeProvider(_a) {\n  var children = _a.children;\n  return React.createElement(react_components_1.FluentProvider, {\n    theme: react_components_1.webLightTheme\n  }, children);\n};\nexports.AppThemeProvider = AppThemeProvider;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../../shared/theme/AppThemeProvider.tsx?\n}");

/***/ },

/***/ "../../shared/theme/index.ts"
/*!***********************************!*\
  !*** ../../shared/theme/index.ts ***!
  \***********************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.appTokens = exports.AppThemeProvider = void 0;\nvar AppThemeProvider_1 = __webpack_require__(/*! ./AppThemeProvider */ \"../../shared/theme/AppThemeProvider.tsx\");\nObject.defineProperty(exports, \"AppThemeProvider\", ({\n  enumerable: true,\n  get: function get() {\n    return AppThemeProvider_1.AppThemeProvider;\n  }\n}));\nvar tokens_1 = __webpack_require__(/*! ./tokens */ \"../../shared/theme/tokens.ts\");\nObject.defineProperty(exports, \"appTokens\", ({\n  enumerable: true,\n  get: function get() {\n    return tokens_1.appTokens;\n  }\n}));\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../../shared/theme/index.ts?\n}");

/***/ },

/***/ "../../shared/theme/tokens.ts"
/*!************************************!*\
  !*** ../../shared/theme/tokens.ts ***!
  \************************************/
(__unused_webpack_module, exports) {

eval("{\n\n// custom design layer\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.appTokens = void 0;\nexports.appTokens = {\n  spacing: {\n    xs: \"4px\",\n    sm: \"8px\",\n    md: \"12px\",\n    lg: \"16px\",\n    xl: \"24px\",\n    xxl: \"32px\"\n  },\n  radius: {\n    sm: \"4px\",\n    md: \"8px\",\n    lg: \"12px\"\n  },\n  typography: {\n    pageTitle: \"24px\",\n    sectionTitle: \"18px\",\n    body: \"14px\",\n    caption: \"12px\"\n  }\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../../shared/theme/tokens.ts?\n}");

/***/ },

/***/ "./src/SalesForm.tsx"
/*!***************************!*\
  !*** ./src/SalesForm.tsx ***!
  \***************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.SalesForm = void 0;\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar react_components_1 = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\nvar styles_1 = __webpack_require__(/*! ./styles */ \"./src/styles.ts\");\nvar handleSubmit_1 = __webpack_require__(/*! ./handlers/handleSubmit */ \"./src/handlers/handleSubmit.ts\");\nvar handleProductChange_1 = __webpack_require__(/*! ./handlers/handleProductChange */ \"./src/handlers/handleProductChange.ts\");\nvar handleRegionChange_1 = __webpack_require__(/*! ./handlers/handleRegionChange */ \"./src/handlers/handleRegionChange.ts\");\nvar handleSaleDateChange_1 = __webpack_require__(/*! ./handlers/handleSaleDateChange */ \"./src/handlers/handleSaleDateChange.ts\");\nvar handleSalesChange_1 = __webpack_require__(/*! ./handlers/handleSalesChange */ \"./src/handlers/handleSalesChange.ts\");\nvar SalesForm = function SalesForm(_a) {\n  var _b, _c, _d, _e, _f;\n  var onSubmit = _a.onSubmit,\n    initialData = _a.initialData;\n  var styles = (0, styles_1.useStyles)();\n  var _g = React.useState((_b = initialData === null || initialData === void 0 ? void 0 : initialData.product) !== null && _b !== void 0 ? _b : \"\"),\n    product = _g[0],\n    setProduct = _g[1];\n  var _h = React.useState((_c = initialData === null || initialData === void 0 ? void 0 : initialData.region) !== null && _c !== void 0 ? _c : \"\"),\n    region = _h[0],\n    setRegion = _h[1];\n  var _j = React.useState((_e = (_d = initialData === null || initialData === void 0 ? void 0 : initialData.sales) === null || _d === void 0 ? void 0 : _d.toString()) !== null && _e !== void 0 ? _e : \"\"),\n    sales = _j[0],\n    setSales = _j[1];\n  var _k = React.useState((_f = initialData === null || initialData === void 0 ? void 0 : initialData.sale_date) !== null && _f !== void 0 ? _f : \"\"),\n    saleDate = _k[0],\n    setSaleDate = _k[1];\n  var _l = React.useState({}),\n    errors = _l[0],\n    setErrors = _l[1];\n  return React.createElement(\"div\", {\n    className: styles.root\n  }, React.createElement(\"h2\", {\n    className: styles.title\n  }, \"Sales Form\"), React.createElement(react_components_1.Field, {\n    className: styles.field,\n    label: \"Product\",\n    required: true,\n    validationState: errors.product ? \"error\" : \"none\",\n    validationMessage: errors.product\n  }, React.createElement(react_components_1.Input, {\n    value: product,\n    onChange: function onChange(event) {\n      return (0, handleProductChange_1.handleProductChange)({\n        event: event,\n        setProduct: setProduct,\n        errors: errors,\n        setErrors: setErrors\n      });\n    },\n    placeholder: \"e.g. Laptop\"\n  })), React.createElement(react_components_1.Field, {\n    className: styles.field,\n    label: \"Region\",\n    required: true,\n    validationState: errors.region ? \"error\" : \"none\",\n    validationMessage: errors.region\n  }, React.createElement(react_components_1.Input, {\n    value: region,\n    onChange: function onChange(event) {\n      return (0, handleRegionChange_1.handleRegionChange)({\n        event: event,\n        setRegion: setRegion,\n        errors: errors,\n        setErrors: setErrors\n      });\n    },\n    placeholder: \"e.g. UK\"\n  })), React.createElement(react_components_1.Field, {\n    className: styles.field,\n    label: \"Sales\",\n    required: true,\n    validationState: errors.sales ? \"error\" : \"none\",\n    validationMessage: errors.sales\n  }, React.createElement(react_components_1.Input, {\n    type: \"number\",\n    value: sales,\n    onChange: function onChange(event) {\n      return (0, handleSalesChange_1.handleSalesChange)({\n        event: event,\n        setSales: setSales,\n        errors: errors,\n        setErrors: setErrors\n      });\n    },\n    placeholder: \"e.g. 1200\"\n  })), React.createElement(react_components_1.Field, {\n    className: styles.field,\n    label: \"Sale Date\",\n    required: true,\n    validationState: errors.sale_date ? \"error\" : \"none\",\n    validationMessage: errors.sale_date\n  }, React.createElement(react_components_1.Input, {\n    type: \"date\",\n    value: saleDate,\n    onChange: function onChange(event) {\n      return (0, handleSaleDateChange_1.handleSaleDateChange)({\n        event: event,\n        setSaleDate: setSaleDate,\n        errors: errors,\n        setErrors: setErrors\n      });\n    }\n  })), React.createElement(react_components_1.Button, {\n    appearance: \"primary\",\n    className: styles.submitButton,\n    onClick: function onClick() {\n      return (0, handleSubmit_1.handleSubmit)({\n        product: product,\n        region: region,\n        sales: sales,\n        saleDate: saleDate,\n        setErrors: setErrors,\n        onSubmit: onSubmit\n      });\n    }\n  }, \"Add Sale\"));\n};\nexports.SalesForm = SalesForm;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/SalesForm.tsx?\n}");

/***/ },

/***/ "./src/handlers/handleProductChange.ts"
/*!*********************************************!*\
  !*** ./src/handlers/handleProductChange.ts ***!
  \*********************************************/
(__unused_webpack_module, exports) {

eval("{\n\nvar __assign = this && this.__assign || function () {\n  __assign = Object.assign || function (t) {\n    for (var s, i = 1, n = arguments.length; i < n; i++) {\n      s = arguments[i];\n      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];\n    }\n    return t;\n  };\n  return __assign.apply(this, arguments);\n};\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.handleProductChange = void 0;\nvar handleProductChange = function handleProductChange(_a) {\n  var event = _a.event,\n    setProduct = _a.setProduct,\n    errors = _a.errors,\n    setErrors = _a.setErrors;\n  var value = event.target.value;\n  setProduct(value);\n  if (errors.product && value.trim()) {\n    setErrors(function (current) {\n      return __assign(__assign({}, current), {\n        product: undefined\n      });\n    });\n  }\n};\nexports.handleProductChange = handleProductChange;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/handlers/handleProductChange.ts?\n}");

/***/ },

/***/ "./src/handlers/handleRegionChange.ts"
/*!********************************************!*\
  !*** ./src/handlers/handleRegionChange.ts ***!
  \********************************************/
(__unused_webpack_module, exports) {

eval("{\n\nvar __assign = this && this.__assign || function () {\n  __assign = Object.assign || function (t) {\n    for (var s, i = 1, n = arguments.length; i < n; i++) {\n      s = arguments[i];\n      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];\n    }\n    return t;\n  };\n  return __assign.apply(this, arguments);\n};\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.handleRegionChange = void 0;\nvar handleRegionChange = function handleRegionChange(_a) {\n  var event = _a.event,\n    setRegion = _a.setRegion,\n    errors = _a.errors,\n    setErrors = _a.setErrors;\n  var value = event.target.value;\n  setRegion(value);\n  if (errors.region && value.trim()) {\n    setErrors(function (current) {\n      return __assign(__assign({}, current), {\n        region: undefined\n      });\n    });\n  }\n};\nexports.handleRegionChange = handleRegionChange;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/handlers/handleRegionChange.ts?\n}");

/***/ },

/***/ "./src/handlers/handleSaleDateChange.ts"
/*!**********************************************!*\
  !*** ./src/handlers/handleSaleDateChange.ts ***!
  \**********************************************/
(__unused_webpack_module, exports) {

eval("{\n\nvar __assign = this && this.__assign || function () {\n  __assign = Object.assign || function (t) {\n    for (var s, i = 1, n = arguments.length; i < n; i++) {\n      s = arguments[i];\n      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];\n    }\n    return t;\n  };\n  return __assign.apply(this, arguments);\n};\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.handleSaleDateChange = void 0;\nvar handleSaleDateChange = function handleSaleDateChange(_a) {\n  var event = _a.event,\n    setSaleDate = _a.setSaleDate,\n    errors = _a.errors,\n    setErrors = _a.setErrors;\n  var value = event.target.value;\n  setSaleDate(value);\n  if (errors.sale_date && value && !Number.isNaN(Date.parse(value))) {\n    setErrors(function (current) {\n      return __assign(__assign({}, current), {\n        sale_date: undefined\n      });\n    });\n  }\n};\nexports.handleSaleDateChange = handleSaleDateChange;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/handlers/handleSaleDateChange.ts?\n}");

/***/ },

/***/ "./src/handlers/handleSalesChange.ts"
/*!*******************************************!*\
  !*** ./src/handlers/handleSalesChange.ts ***!
  \*******************************************/
(__unused_webpack_module, exports) {

eval("{\n\nvar __assign = this && this.__assign || function () {\n  __assign = Object.assign || function (t) {\n    for (var s, i = 1, n = arguments.length; i < n; i++) {\n      s = arguments[i];\n      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];\n    }\n    return t;\n  };\n  return __assign.apply(this, arguments);\n};\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.handleSalesChange = void 0;\nvar handleSalesChange = function handleSalesChange(_a) {\n  var event = _a.event,\n    setSales = _a.setSales,\n    errors = _a.errors,\n    setErrors = _a.setErrors;\n  var value = event.target.value;\n  setSales(value);\n  var numericValue = Number(value);\n  if (errors.sales && value.trim() && !Number.isNaN(numericValue) && numericValue > 0) {\n    setErrors(function (current) {\n      return __assign(__assign({}, current), {\n        sales: undefined\n      });\n    });\n  }\n};\nexports.handleSalesChange = handleSalesChange;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/handlers/handleSalesChange.ts?\n}");

/***/ },

/***/ "./src/handlers/handleSubmit.ts"
/*!**************************************!*\
  !*** ./src/handlers/handleSubmit.ts ***!
  \**************************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.handleSubmit = void 0;\nvar validate_1 = __webpack_require__(/*! ../validate */ \"./src/validate.ts\");\nvar handleSubmit = function handleSubmit(_a) {\n  var product = _a.product,\n    region = _a.region,\n    sales = _a.sales,\n    saleDate = _a.saleDate,\n    setErrors = _a.setErrors,\n    onSubmit = _a.onSubmit;\n  var validationErrors = (0, validate_1.validate)({\n    product: product,\n    region: region,\n    sales: sales,\n    saleDate: saleDate\n  });\n  setErrors(validationErrors);\n  if (Object.keys(validationErrors).length > 0) {\n    return;\n  }\n  var formData = {\n    product: product.trim(),\n    region: region.trim(),\n    sales: Number(sales),\n    sale_date: saleDate\n  };\n  onSubmit(formData);\n};\nexports.handleSubmit = handleSubmit;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/handlers/handleSubmit.ts?\n}");

/***/ },

/***/ "./src/index.ts"
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.SalesFormControl = void 0;\nvar SalesForm_1 = __webpack_require__(/*! ./SalesForm */ \"./src/SalesForm.tsx\");\nvar theme_1 = __webpack_require__(/*! ../../../shared/theme */ \"../../shared/theme/index.ts\");\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar SalesFormControl = /** @class */function () {\n  function SalesFormControl() {\n    this.submittedData = \"\";\n    // Empty\n  }\n  SalesFormControl.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  SalesFormControl.prototype.updateView = function (context) {\n    var _this = this;\n    var props = {\n      onSubmit: function onSubmit(data) {\n        _this.submittedData = JSON.stringify(data);\n        _this.notifyOutputChanged();\n      }\n    };\n    return React.createElement(theme_1.AppThemeProvider, null, React.createElement(SalesForm_1.SalesForm, props));\n  };\n  SalesFormControl.prototype.getOutputs = function () {\n    return {\n      submittedData: this.submittedData\n    };\n  };\n  SalesFormControl.prototype.destroy = function () {\n    // Cleanup if required\n  };\n  return SalesFormControl;\n}();\nexports.SalesFormControl = SalesFormControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/index.ts?\n}");

/***/ },

/***/ "./src/styles.ts"
/*!***********************!*\
  !*** ./src/styles.ts ***!
  \***********************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.useStyles = void 0;\nvar react_components_1 = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\nvar theme_1 = __webpack_require__(/*! ../../../shared/theme */ \"../../shared/theme/index.ts\");\nexports.useStyles = (0, react_components_1.makeStyles)({\n  root: {\n    padding: theme_1.appTokens.spacing.xxl,\n    backgroundColor: \"#0e1b2d\",\n    borderRadius: \"25px\",\n    maxWidth: \"500px\"\n  },\n  title: {\n    fontSize: theme_1.appTokens.typography.pageTitle,\n    color: \"#ffffff\",\n    marginTop: 0\n  },\n  field: {\n    marginBottom: theme_1.appTokens.spacing.md,\n    \"& label\": {\n      color: \"#ffffff !important\"\n    }\n  },\n  submitButton: {\n    marginTop: theme_1.appTokens.spacing.md,\n    backgroundColor: \"#3cd7d9\",\n    color: \"#0e1b2d\",\n    \":hover\": {\n      backgroundColor: \"#a7edee\",\n      color: \"#0e1b2d\"\n    }\n  }\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/styles.ts?\n}");

/***/ },

/***/ "./src/validate.ts"
/*!*************************!*\
  !*** ./src/validate.ts ***!
  \*************************/
(__unused_webpack_module, exports) {

eval("{\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.validate = void 0;\nvar validate = function validate(_a) {\n  var product = _a.product,\n    region = _a.region,\n    sales = _a.sales,\n    saleDate = _a.saleDate;\n  var validationErrors = {};\n  if (!product.trim()) {\n    validationErrors.product = \"Product is required\";\n  }\n  if (!region.trim()) {\n    validationErrors.region = \"Region is required\";\n  }\n  if (!sales.trim()) {\n    validationErrors.sales = \"Sales amount is required\";\n  } else if (Number.isNaN(Number(sales))) {\n    validationErrors.sales = \"Sales must be a valid number\";\n  } else if (Number(sales) <= 0) {\n    validationErrors.sales = \"Sales must be greater than 0\";\n  }\n  if (!saleDate) {\n    validationErrors.sale_date = \"Sale date is required\";\n  } else if (Number.isNaN(Date.parse(saleDate))) {\n    validationErrors.sale_date = \"Please enter a valid date\";\n  }\n  return validationErrors;\n};\nexports.validate = validate;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/validate.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	let __webpack_exports__ = __webpack_require__("./src/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Demo.SalesFormControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesFormControl);
} else {
	var Demo = Demo || {};
	Demo.SalesFormControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesFormControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}