/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/SalesKPI.tsx"
/*!**************************!*\
  !*** ./src/SalesKPI.tsx ***!
  \**************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.SalesKPIView = void 0;\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar SalesKPIView = function SalesKPIView(_a) {\n  var data = _a.data;\n  return React.createElement(\"div\", {\n    style: {\n      padding: \"16px\"\n    }\n  }, React.createElement(\"h2\", null, \"Sales KPI\"), React.createElement(\"p\", null, \"KPI metrics component coming soon...\"), React.createElement(\"p\", null, \"Data: \", data.substring(0, 100), \"...\"));\n};\nexports.SalesKPIView = SalesKPIView;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/SalesKPI.tsx?\n}");

/***/ },

/***/ "./src/index.ts"
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.SalesKPI = void 0;\nvar SalesKPI_1 = __webpack_require__(/*! ./SalesKPI */ \"./src/SalesKPI.tsx\");\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar SalesKPI = /** @class */function () {\n  function SalesKPI() {\n    // Empty\n  }\n  SalesKPI.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  SalesKPI.prototype.updateView = function (context) {\n    var _a;\n    var props = {\n      data: (_a = context.parameters.salesData.raw) !== null && _a !== void 0 ? _a : \"\"\n    };\n    return React.createElement(SalesKPI_1.SalesKPIView, props);\n  };\n  SalesKPI.prototype.getOutputs = function () {\n    return {};\n  };\n  SalesKPI.prototype.destroy = function () {\n    // Cleanup if required\n  };\n  return SalesKPI;\n}();\nexports.SalesKPI = SalesKPI;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	let __webpack_exports__ = __webpack_require__("./src/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Demo.SalesKPI', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesKPI);
} else {
	var Demo = Demo || {};
	Demo.SalesKPI = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesKPI;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}