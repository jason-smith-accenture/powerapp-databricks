/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../shared/theme/AppThemeProvider.tsx"
/*!***********************************************!*\
  !*** ../../shared/theme/AppThemeProvider.tsx ***!
  \***********************************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.AppThemeProvider = void 0;\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar react_components_1 = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\nvar AppThemeProvider = function AppThemeProvider(_a) {\n  var children = _a.children;\n  return React.createElement(react_components_1.FluentProvider, {\n    theme: react_components_1.webLightTheme\n  }, children);\n};\nexports.AppThemeProvider = AppThemeProvider;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../../shared/theme/AppThemeProvider.tsx?\n}");

/***/ },

/***/ "../../shared/theme/index.ts"
/*!***********************************!*\
  !*** ../../shared/theme/index.ts ***!
  \***********************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.appTokens = exports.AppThemeProvider = void 0;\nvar AppThemeProvider_1 = __webpack_require__(/*! ./AppThemeProvider */ \"../../shared/theme/AppThemeProvider.tsx\");\nObject.defineProperty(exports, \"AppThemeProvider\", ({\n  enumerable: true,\n  get: function get() {\n    return AppThemeProvider_1.AppThemeProvider;\n  }\n}));\nvar tokens_1 = __webpack_require__(/*! ./tokens */ \"../../shared/theme/tokens.ts\");\nObject.defineProperty(exports, \"appTokens\", ({\n  enumerable: true,\n  get: function get() {\n    return tokens_1.appTokens;\n  }\n}));\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../../shared/theme/index.ts?\n}");

/***/ },

/***/ "../../shared/theme/tokens.ts"
/*!************************************!*\
  !*** ../../shared/theme/tokens.ts ***!
  \************************************/
(__unused_webpack_module, exports) {

eval("{\n\n// custom design layer\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.appTokens = void 0;\nexports.appTokens = {\n  spacing: {\n    xs: \"4px\",\n    sm: \"8px\",\n    md: \"12px\",\n    lg: \"16px\",\n    xl: \"24px\",\n    xxl: \"32px\"\n  },\n  radius: {\n    sm: \"4px\",\n    md: \"8px\",\n    lg: \"12px\"\n  },\n  typography: {\n    pageTitle: \"24px\",\n    sectionTitle: \"18px\",\n    body: \"14px\",\n    caption: \"12px\"\n  }\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../../shared/theme/tokens.ts?\n}");

/***/ },

/***/ "./src/Filter.tsx"
/*!************************!*\
  !*** ./src/Filter.tsx ***!
  \************************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __assign = this && this.__assign || function () {\n  __assign = Object.assign || function (t) {\n    for (var s, i = 1, n = arguments.length; i < n; i++) {\n      s = arguments[i];\n      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];\n    }\n    return t;\n  };\n  return __assign.apply(this, arguments);\n};\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.Filter = void 0;\nvar react_1 = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar react_components_1 = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\nvar styles_1 = __webpack_require__(/*! ./styles */ \"./src/styles.ts\");\nvar Filter = function Filter(_a) {\n  var fields = _a.fields,\n    _b = _a.initialValues,\n    initialValues = _b === void 0 ? {} : _b,\n    onApply = _a.onApply,\n    onChange = _a.onChange,\n    onClear = _a.onClear,\n    _c = _a.showApplyButton,\n    showApplyButton = _c === void 0 ? true : _c,\n    _d = _a.showClearButton,\n    showClearButton = _d === void 0 ? true : _d;\n  var styles = (0, styles_1.useStyles)();\n  var _e = (0, react_1.useState)(function () {\n      return initialValues;\n    }),\n    values = _e[0],\n    setValues = _e[1];\n  var updateValue = function updateValue(fieldId, value) {\n    setValues(function (currentValues) {\n      var _a;\n      var updatedValues = __assign(__assign({}, currentValues), (_a = {}, _a[fieldId] = value, _a));\n      onChange === null || onChange === void 0 ? void 0 : onChange(updatedValues);\n      return updatedValues;\n    });\n  };\n  var handleApply = function handleApply() {\n    onApply === null || onApply === void 0 ? void 0 : onApply(values);\n  };\n  var handleClear = function handleClear() {\n    var clearedValues = {};\n    setValues(clearedValues);\n    onChange === null || onChange === void 0 ? void 0 : onChange(clearedValues);\n    onClear === null || onClear === void 0 ? void 0 : onClear();\n  };\n  var renderField = function renderField(field) {\n    var _a, _b, _c;\n    var value = (_a = values[field.id]) !== null && _a !== void 0 ? _a : \"\";\n    switch (field.type) {\n      case \"text\":\n        return react_1.default.createElement(\"div\", {\n          key: field.id,\n          className: styles.field\n        }, react_1.default.createElement(react_components_1.Field, {\n          label: field.label\n        }, react_1.default.createElement(react_components_1.Input, {\n          value: value,\n          placeholder: field.placeholder,\n          disabled: field.disabled,\n          onChange: function onChange(event) {\n            updateValue(field.id, event.target.value);\n          }\n        })));\n      case \"select\":\n        return react_1.default.createElement(\"div\", {\n          key: field.id,\n          className: styles.field\n        }, react_1.default.createElement(react_components_1.Field, {\n          label: field.label\n        }, react_1.default.createElement(react_components_1.Select, {\n          value: value,\n          disabled: field.disabled,\n          onChange: function onChange(event) {\n            updateValue(field.id, event.target.value);\n          }\n        }, react_1.default.createElement(\"option\", {\n          value: \"\"\n        }, (_b = field.placeholder) !== null && _b !== void 0 ? _b : \"Select \".concat(field.label)), (_c = field.options) === null || _c === void 0 ? void 0 : _c.map(function (option) {\n          return react_1.default.createElement(\"option\", {\n            key: option.value,\n            value: option.value\n          }, option.label);\n        }))));\n      case \"date\":\n        return react_1.default.createElement(\"div\", {\n          key: field.id,\n          className: styles.field\n        }, react_1.default.createElement(react_components_1.Field, {\n          label: field.label\n        }, react_1.default.createElement(react_components_1.Input, {\n          type: \"date\",\n          value: value,\n          disabled: field.disabled,\n          onChange: function onChange(event) {\n            updateValue(field.id, event.target.value);\n          }\n        })));\n      default:\n        return null;\n    }\n  };\n  return react_1.default.createElement(\"section\", {\n    className: styles.root\n  }, react_1.default.createElement(\"div\", {\n    className: styles.header\n  }, react_1.default.createElement(\"h2\", {\n    className: styles.title\n  }, \"Filters\"), react_1.default.createElement(\"p\", {\n    className: styles.description\n  }, \"Refine the data displayed in the table.\")), react_1.default.createElement(\"div\", {\n    className: styles.fields\n  }, fields.map(renderField)), (showApplyButton || showClearButton) && react_1.default.createElement(\"div\", {\n    className: styles.actions\n  }, showClearButton && react_1.default.createElement(react_components_1.Button, {\n    appearance: \"secondary\",\n    onClick: handleClear\n  }, \"Clear\"), showApplyButton && react_1.default.createElement(react_components_1.Button, {\n    appearance: \"primary\",\n    onClick: handleApply\n  }, \"Apply filters\")));\n};\nexports.Filter = Filter;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/Filter.tsx?\n}");

/***/ },

/***/ "./src/index.ts"
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nvar __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  var desc = Object.getOwnPropertyDescriptor(m, k);\n  if (!desc || (\"get\" in desc ? !m.__esModule : desc.writable || desc.configurable)) {\n    desc = {\n      enumerable: true,\n      get: function get() {\n        return m[k];\n      }\n    };\n  }\n  Object.defineProperty(o, k2, desc);\n} : function (o, m, k, k2) {\n  if (k2 === undefined) k2 = k;\n  o[k2] = m[k];\n});\nvar __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {\n  Object.defineProperty(o, \"default\", {\n    enumerable: true,\n    value: v\n  });\n} : function (o, v) {\n  o[\"default\"] = v;\n});\nvar __importStar = this && this.__importStar || function () {\n  var _ownKeys = function ownKeys(o) {\n    _ownKeys = Object.getOwnPropertyNames || function (o) {\n      var ar = [];\n      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;\n      return ar;\n    };\n    return _ownKeys(o);\n  };\n  return function (mod) {\n    if (mod && mod.__esModule) return mod;\n    var result = {};\n    if (mod != null) for (var k = _ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== \"default\") __createBinding(result, mod, k[i]);\n    __setModuleDefault(result, mod);\n    return result;\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.SalesFilter = void 0;\nvar React = __importStar(__webpack_require__(/*! react */ \"react\"));\nvar Filter_1 = __webpack_require__(/*! ./Filter */ \"./src/Filter.tsx\");\nvar SalesFilter = /** @class */function () {\n  function SalesFilter() {\n    this.filters = {};\n    this.notifyOutputChanged = function () {};\n  }\n  SalesFilter.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  SalesFilter.prototype.updateView = function (context) {\n    var _this = this;\n    return React.createElement(Filter_1.Filter, {\n      fields: [{\n        id: \"product\",\n        label: \"Product\",\n        type: \"select\",\n        placeholder: \"All products\",\n        options: [{\n          label: \"Mortgage\",\n          value: \"mortgage\"\n        }, {\n          label: \"Savings\",\n          value: \"savings\"\n        }, {\n          label: \"Credit Card\",\n          value: \"credit-card\"\n        }]\n      }, {\n        id: \"region\",\n        label: \"Region\",\n        type: \"select\",\n        placeholder: \"All regions\",\n        options: [{\n          label: \"North\",\n          value: \"north\"\n        }, {\n          label: \"South\",\n          value: \"south\"\n        }, {\n          label: \"East\",\n          value: \"east\"\n        }, {\n          label: \"West\",\n          value: \"west\"\n        }]\n      }, {\n        id: \"dateFrom\",\n        label: \"From\",\n        type: \"date\"\n      }, {\n        id: \"dateTo\",\n        label: \"To\",\n        type: \"date\"\n      }],\n      onChange: function onChange(filters) {\n        _this.filters = filters;\n        _this.notifyOutputChanged();\n      }\n    });\n  };\n  SalesFilter.prototype.getOutputs = function () {\n    return {};\n  };\n  SalesFilter.prototype.destroy = function () {\n    // Nothing to clean up.\n  };\n  return SalesFilter;\n}();\nexports.SalesFilter = SalesFilter;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/index.ts?\n}");

/***/ },

/***/ "./src/styles.ts"
/*!***********************!*\
  !*** ./src/styles.ts ***!
  \***********************/
(__unused_webpack_module, exports, __webpack_require__) {

eval("{\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.useStyles = void 0;\nvar react_components_1 = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\nvar theme_1 = __webpack_require__(/*! ../../../shared/theme */ \"../../shared/theme/index.ts\");\nexports.useStyles = (0, react_components_1.makeStyles)({\n  root: {\n    width: \"100%\",\n    boxSizing: \"border-box\",\n    padding: theme_1.appTokens.spacing.lg,\n    backgroundColor: \"#0e1b2d\",\n    borderRadius: \"25px\",\n    color: \"white\"\n  },\n  header: {\n    marginBottom: theme_1.appTokens.spacing.lg\n  },\n  title: {\n    margin: 0,\n    marginBottom: theme_1.appTokens.spacing.xs,\n    fontSize: theme_1.appTokens.typography.pageTitle,\n    fontWeight: 600\n  },\n  description: {\n    margin: 0,\n    fontSize: theme_1.appTokens.typography.body,\n    color: \"#c5ced9\"\n  },\n  fields: {\n    display: \"grid\",\n    gridTemplateColumns: \"repeat(auto-fit, minmax(180px, 1fr))\",\n    gap: theme_1.appTokens.spacing.md\n  },\n  field: {\n    minWidth: 0\n  },\n  actions: {\n    display: \"flex\",\n    justifyContent: \"flex-end\",\n    gap: theme_1.appTokens.spacing.sm,\n    marginTop: theme_1.appTokens.spacing.lg\n  }\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./src/styles.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	let __webpack_exports__ = __webpack_require__("./src/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Demo.SalesFilter', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesFilter);
} else {
	var Demo = Demo || {};
	Demo.SalesFilter = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SalesFilter;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}